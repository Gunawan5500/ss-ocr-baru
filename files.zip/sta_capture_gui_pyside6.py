"""
GUI Desktop untuk STA Screenshot Capture - PySide6 Version
Fitur: Live video preview, interactive ROI selection, real-time OCR, processing log
Built for VS Code development environment
"""

import sys
import os
import re
import threading
from pathlib import Path
from datetime import datetime

import cv2
import pytesseract
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
    QLabel, QPushButton, QSpinBox, QDoubleSpinBox, QLineEdit, QFileDialog,
    QTabWidget, QFrame, QSlider, QComboBox, QTextEdit, QProgressBar,
    QGroupBox, QGridLayout, QCheckBox, QStatusBar, QMessageBox
)
from PySide6.QtGui import QImage, QPixmap, QFont, QColor, QPainter, QPen
from PySide6.QtCore import Qt, QTimer, Signal, QObject, QThread, QRect

STA_REGEX = re.compile(r'(\d{1,4})\s*\+\s*(\d{1,3}(?:\.\d{1,2})?)')


class WorkerSignals(QObject):
    """Signals untuk worker thread"""
    progress = Signal(int)
    finished = Signal()
    log = Signal(str)
    stats = Signal(dict)


class ProcessWorker(QThread):
    """Worker thread untuk processing video tanpa freeze UI"""
    signals = WorkerSignals()
    
    def __init__(self, video_path, roi, interval, output_folder, frame_skip):
        super().__init__()
        self.video_path = video_path
        self.roi = roi
        self.interval = interval
        self.output_folder = output_folder
        self.frame_skip = frame_skip
        self.is_running = True
    
    def run(self):
        try:
            cap = cv2.VideoCapture(self.video_path)
            if not cap.isOpened():
                self.signals.log.emit("❌ Gagal membuka video")
                return
            
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            x, y, w, h = self.roi
            
            frame_idx = 0
            last_saved_multiple = None
            last_value = None
            saved_count = 0
            read_attempts = 0
            read_success = 0
            
            self.signals.log.emit(f"📹 Total frames: {total_frames}")
            self.signals.log.emit(f"🎯 ROI: x={x}, y={y}, w={w}, h={h}")
            self.signals.log.emit(f"📏 Interval: {self.interval}m\n")
            
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                if not self.is_running:
                    self.signals.log.emit("⏹️  Processing dihentikan oleh user")
                    break
                
                if frame_idx % self.frame_skip == 0:
                    roi_img = frame[y:y + h, x:x + w]
                    proc = self.preprocess(roi_img)
                    text = self.ocr_read(proc)
                    value = self.parse_sta(text)
                    read_attempts += 1
                    
                    if value is not None:
                        read_success += 1
                        if last_value is not None:
                            diff = value - last_value
                            if diff < -5 or diff > self.interval * 5:
                                frame_idx += 1
                                continue
                        last_value = value
                        
                        current_multiple = int(value // self.interval) * self.interval
                        if last_saved_multiple is None or current_multiple > last_saved_multiple:
                            last_saved_multiple = current_multiple
                            km = int(current_multiple // 1000)
                            m = int(current_multiple % 1000)
                            filename = f'STA_{km}+{m:03d}.jpg'
                            filepath = os.path.join(self.output_folder, filename)
                            cv2.imwrite(filepath, frame)
                            saved_count += 1
                            self.signals.log.emit(f'✓ {filename}  (OCR: "{text}")')
                
                frame_idx += 1
                progress = int(100 * frame_idx / total_frames)
                self.signals.progress.emit(progress)
            
            cap.release()
            stats = {
                'saved': saved_count,
                'attempts': read_attempts,
                'success': read_success,
                'accuracy': (100 * read_success / read_attempts) if read_attempts > 0 else 0
            }
            self.signals.stats.emit(stats)
            self.signals.finished.emit()
            
        except Exception as e:
            self.signals.log.emit(f"❌ Error: {str(e)}")
            self.signals.finished.emit()
    
    def stop(self):
        self.is_running = False
    
    @staticmethod
    def parse_sta(text):
        match = STA_REGEX.search(text)
        if not match:
            return None
        km = int(match.group(1))
        m = float(match.group(2))
        return km * 1000 + m
    
    @staticmethod
    def preprocess(roi_img, scale=3):
        gray = cv2.cvtColor(roi_img, cv2.COLOR_BGR2GRAY)
        gray = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
        gray = cv2.GaussianBlur(gray, (3, 3), 0)
        _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        return thresh
    
    @staticmethod
    def ocr_read(img):
        config = '--psm 7 -c tessedit_char_whitelist=0123456789+.STA'
        text = pytesseract.image_to_string(img, config=config)
        return text.strip()


class VideoPreviewWidget(QFrame):
    """Widget untuk display preview video dengan ROI selection"""
    def __init__(self):
        super().__init__()
        self.label = QLabel()
        self.label.setStyleSheet("background-color: #0a0a0a; border: 2px solid #1e3a5f;")
        self.label.setMinimumSize(640, 480)
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        layout = QVBoxLayout()
        layout.addWidget(self.label)
        layout.setContentsMargins(0, 0, 0, 0)
        self.setLayout(layout)
        
        self.roi_rect = None
        self.mouse_down = False
        self.start_point = None
        self.label.mousePressEvent = self._on_mouse_press
        self.label.mouseMoveEvent = self._on_mouse_move
        self.label.mouseReleaseEvent = self._on_mouse_release
    
    def set_pixmap(self, pixmap, roi=None):
        """Set pixmap dengan optional ROI rectangle"""
        if roi:
            painter = QPainter(pixmap)
            painter.setPen(QPen(QColor("#f59e0b"), 3, Qt.PenStyle.SolidLine))
            x, y, w, h = roi
            painter.drawRect(x, y, w, h)
            painter.end()
        self.label.setPixmap(pixmap)
    
    def _on_mouse_press(self, event):
        self.start_point = event.pos()
        self.mouse_down = True
    
    def _on_mouse_move(self, event):
        if self.mouse_down and self.start_point:
            self.roi_rect = QRect(self.start_point, event.pos())
    
    def _on_mouse_release(self, event):
        self.mouse_down = False


class STACaptureGUI(QMainWindow):
    """Main GUI Application - PySide6 Version"""
    def __init__(self):
        super().__init__()
        self.setWindowTitle("STA Screenshot Capture - PySide6")
        self.setGeometry(100, 100, 1200, 800)
        self.setStyleSheet(self._get_stylesheet())
        
        self.video_path = None
        self.cap = None
        self.video_fps = 0
        self.current_frame = None
        self.current_frame_idx = 0
        self.total_frames = 0
        
        self.roi = None
        self.is_playing = False
        self.worker = None
        
        self._init_ui()
        
    def _get_stylesheet(self):
        """Dark theme dengan accent oranye"""
        return """
            QMainWindow, QWidget { 
                background-color: #0f172a; 
                color: #e2e8f0; 
            }
            QTabWidget::pane { 
                border: 1px solid #1e293b; 
            }
            QTabBar::tab { 
                background-color: #1e293b; 
                color: #94a3b8; 
                padding: 8px 20px; 
            }
            QTabBar::tab:selected { 
                background-color: #f59e0b; 
                color: #000; 
            }
            
            QLabel { 
                color: #e2e8f0; 
            }
            QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox {
                background-color: #1e293b; 
                color: #e2e8f0;
                border: 1px solid #334155; 
                border-radius: 4px; 
                padding: 6px;
                selection-background-color: #f59e0b;
            }
            QPushButton {
                background-color: #1e40af; 
                color: #fff; 
                border: none;
                border-radius: 4px; 
                padding: 8px 16px; 
                font-weight: bold;
                min-width: 80px;
            }
            QPushButton:hover { 
                background-color: #1e3a8a; 
            }
            QPushButton:pressed { 
                background-color: #172554; 
            }
            
            QPushButton#accentBtn {
                background-color: #f59e0b;
                color: #000;
            }
            QPushButton#accentBtn:hover { 
                background-color: #d97706; 
            }
            
            QTextEdit {
                background-color: #0f172a; 
                color: #10b981;
                border: 1px solid #1e293b; 
                border-radius: 4px;
                font-family: 'Courier New'; 
                font-size: 10px;
            }
            QGroupBox {
                color: #cbd5e1; 
                border: 1px solid #334155;
                border-radius: 4px; 
                padding: 12px; 
                margin-top: 12px;
            }
            QGroupBox::title { 
                subcontrol-origin: margin; 
                top: -6px; 
            }
            
            QProgressBar {
                border: 1px solid #334155; 
                border-radius: 4px;
                background-color: #1e293b;
                text-align: center;
            }
            QProgressBar::chunk { 
                background-color: #f59e0b; 
            }
            
            QStatusBar { 
                background-color: #1e293b; 
                color: #94a3b8;
            }
        """
    
    def _init_ui(self):
        """Initialize UI components"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QHBoxLayout()
        
        # Left panel: Video preview
        left_panel = self._create_left_panel()
        
        # Right panel: Tabs
        tabs = QTabWidget()
        tabs.addTab(self._create_video_settings_tab(), "📹 Video & ROI")
        tabs.addTab(self._create_settings_tab(), "⚙️  Settings")
        tabs.addTab(self._create_processing_tab(), "▶️  Process")
        
        main_layout.addWidget(left_panel, 1)
        main_layout.addWidget(tabs, 1)
        
        central_widget.setLayout(main_layout)
        self.setStatusBar(QStatusBar())
        self.statusBar().showMessage("Ready")
    
    def _create_left_panel(self):
        """Video preview panel"""
        panel = QFrame()
        layout = QVBoxLayout()
        
        label = QLabel("📹 Video Preview")
        label.setFont(QFont("Arial", 11, QFont.Weight.Bold))
        
        self.preview_widget = VideoPreviewWidget()
        
        controls_layout = QHBoxLayout()
        
        self.play_btn = QPushButton("▶ Play")
        self.play_btn.clicked.connect(self._toggle_play)
        self.play_btn.setMaximumWidth(100)
        
        self.frame_slider = QSlider(Qt.Orientation.Horizontal)
        self.frame_slider.setMinimum(0)
        self.frame_slider.sliderMoved.connect(self._on_slider_moved)
        self.frame_slider.setTracking(False)
        
        self.frame_label = QLabel("0 / 0")
        self.frame_label.setMinimumWidth(100)
        self.frame_label.setFont(QFont("Courier New", 10, QFont.Weight.Bold))
        
        controls_layout.addWidget(self.play_btn)
        controls_layout.addWidget(self.frame_slider, 1)
        controls_layout.addWidget(self.frame_label)
        
        layout.addWidget(label)
        layout.addWidget(self.preview_widget, 1)
        layout.addLayout(controls_layout)
        panel.setLayout(layout)
        
        self.preview_timer = QTimer()
        self.preview_timer.timeout.connect(self._update_preview)
        
        return panel
    
    def _create_video_settings_tab(self):
        """Tab untuk video input & ROI selection"""
        tab = QWidget()
        layout = QVBoxLayout()
        
        # Video selection group
        video_group = QGroupBox("Select Video")
        video_layout = QHBoxLayout()
        self.video_input = QLineEdit()
        self.video_input.setPlaceholderText("No video selected")
        self.video_input.setReadOnly(True)
        self.video_btn = QPushButton("Browse...")
        self.video_btn.clicked.connect(self._select_video)
        video_layout.addWidget(self.video_input)
        video_layout.addWidget(self.video_btn)
        video_group.setLayout(video_layout)
        
        # ROI group
        roi_group = QGroupBox("Define STA Text Region (ROI)")
        roi_layout = QGridLayout()
        
        roi_info = QLabel("Gambar ROI di preview video atau input manual koordinat pixel")
        roi_info.setStyleSheet("color: #94a3b8; font-size: 9px;")
        roi_layout.addWidget(roi_info, 0, 0, 1, 2)
        
        roi_labels = ["X", "Y", "Width", "Height"]
        self.roi_spinboxes = {}
        
        for i, label in enumerate(roi_labels):
            lbl = QLabel(f"{label}:")
            spin = QSpinBox()
            spin.setRange(0, 2000)
            spin.setValue(0)
            spin.valueChanged.connect(self._on_roi_changed)
            self.roi_spinboxes[label.lower()] = spin
            roi_layout.addWidget(lbl, i+1, 0)
            roi_layout.addWidget(spin, i+1, 1)
        
        self.roi_draw_btn = QPushButton("📍 Draw ROI on Preview")
        self.roi_draw_btn.setObjectName("accentBtn")
        roi_layout.addWidget(self.roi_draw_btn, 5, 0, 1, 2)
        
        roi_group.setLayout(roi_layout)
        
        # Live OCR preview
        ocr_group = QGroupBox("Live OCR Preview")
        ocr_layout = QVBoxLayout()
        self.ocr_display = QLabel("No frame loaded")
        self.ocr_display.setFont(QFont("Courier New", 16, QFont.Weight.Bold))
        self.ocr_display.setStyleSheet(
            "color: #f59e0b; background-color: #0a0a0a; padding: 15px; border-radius: 4px; border: 1px solid #f59e0b;"
        )
        self.ocr_display.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.ocr_display.setMinimumHeight(80)
        ocr_layout.addWidget(self.ocr_display)
        ocr_group.setLayout(ocr_layout)
        
        layout.addWidget(video_group)
        layout.addWidget(roi_group)
        layout.addWidget(ocr_group)
        layout.addStretch()
        
        return tab
    
    def _create_settings_tab(self):
        """Tab untuk settings processing"""
        tab = QWidget()
        layout = QVBoxLayout()
        
        settings_group = QGroupBox("Processing Parameters")
        settings_layout = QGridLayout()
        
        # Interval
        lbl_interval = QLabel("Capture Interval (meters):")
        self.interval_spin = QDoubleSpinBox()
        self.interval_spin.setRange(1, 1000)
        self.interval_spin.setValue(100)
        self.interval_spin.setSuffix(" m")
        settings_layout.addWidget(lbl_interval, 0, 0)
        settings_layout.addWidget(self.interval_spin, 0, 1)
        
        # Frame skip
        lbl_skip = QLabel("Frame Skip:")
        self.skip_spin = QSpinBox()
        self.skip_spin.setRange(1, 30)
        self.skip_spin.setValue(5)
        self.skip_spin.setSuffix(" frame")
        settings_layout.addWidget(lbl_skip, 1, 0)
        settings_layout.addWidget(self.skip_spin, 1, 1)
        
        # Output folder
        lbl_output = QLabel("Output Folder:")
        self.output_input = QLineEdit()
        self.output_input.setText(str(Path.home() / "STA_Output"))
        self.output_btn = QPushButton("Browse...")
        self.output_btn.clicked.connect(self._select_output)
        settings_layout.addWidget(lbl_output, 2, 0)
        settings_layout.addWidget(self.output_input, 2, 1)
        settings_layout.addWidget(self.output_btn, 2, 2)
        
        settings_group.setLayout(settings_layout)
        
        layout.addWidget(settings_group)
        layout.addStretch()
        
        return tab
    
    def _create_processing_tab(self):
        """Tab untuk processing & log"""
        tab = QWidget()
        layout = QVBoxLayout()
        
        # Controls
        controls_layout = QHBoxLayout()
        self.process_btn = QPushButton("▶ Start Processing")
        self.process_btn.setObjectName("accentBtn")
        self.process_btn.setMinimumHeight(40)
        self.process_btn.clicked.connect(self._start_processing)
        
        self.stop_btn = QPushButton("⏹ Stop")
        self.stop_btn.setEnabled(False)
        self.stop_btn.setMinimumHeight(40)
        self.stop_btn.clicked.connect(self._stop_processing)
        
        controls_layout.addWidget(self.process_btn, 1)
        controls_layout.addWidget(self.stop_btn, 1)
        
        # Progress
        self.progress_bar = QProgressBar()
        self.progress_bar.setStyleSheet("""
            QProgressBar { 
                border: 1px solid #334155; 
                border-radius: 4px; 
                background-color: #1e293b;
            }
            QProgressBar::chunk { 
                background-color: #10b981; 
            }
        """)
        self.progress_bar.setTextVisible(True)
        
        # Log display
        log_label = QLabel("📋 Processing Log:")
        log_label.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        self.log_display = QTextEdit()
        self.log_display.setReadOnly(True)
        self.log_display.setMinimumHeight(250)
        
        # Stats
        stats_label = QLabel("📊 Statistics:")
        stats_label.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        self.stats_display = QLabel("Waiting for processing...")
        self.stats_display.setStyleSheet("color: #94a3b8; padding: 10px; background-color: #1e293b; border-radius: 4px;")
        self.stats_display.setMinimumHeight(100)
        
        layout.addLayout(controls_layout)
        layout.addWidget(self.progress_bar)
        layout.addWidget(log_label)
        layout.addWidget(self.log_display, 1)
        layout.addWidget(stats_label)
        layout.addWidget(self.stats_display)
        
        return tab
    
    def _select_video(self):
        """Select video file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Video", "", "Video Files (*.mp4 *.avi *.mov *.mkv);;All Files (*)"
        )
        if file_path:
            self.video_path = file_path
            self.video_input.setText(file_path)
            self._load_video()
            self.statusBar().showMessage(f"✓ Video loaded: {Path(file_path).name}")
    
    def _load_video(self):
        """Load video dan set properties"""
        if not self.video_path:
            return
        
        if self.cap:
            self.cap.release()
        
        self.cap = cv2.VideoCapture(self.video_path)
        self.total_frames = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))
        self.video_fps = self.cap.get(cv2.CAP_PROP_FPS)
        
        self.frame_slider.setMaximum(self.total_frames - 1)
        self._show_frame(0)
    
    def _show_frame(self, frame_idx):
        """Display specific frame"""
        if not self.cap:
            return
        
        self.cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
        ret, frame = self.cap.read()
        
        if ret:
            self.current_frame = frame
            self.current_frame_idx = frame_idx
            
            # Convert to RGB dan resize untuk preview
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w, ch = frame_rgb.shape
            bytes_per_line = 3 * w
            qt_img = QImage(frame_rgb.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)
            pixmap = QPixmap.fromImage(qt_img)
            
            # Scale untuk fit widget
            scaled_pixmap = pixmap.scaledToWidth(640, Qt.TransformationMode.SmoothTransformation)
            
            self.preview_widget.set_pixmap(scaled_pixmap, self.roi)
            self.frame_label.setText(f"{frame_idx + 1} / {self.total_frames}")
            
            # Show live OCR
            if self.roi:
                self._update_ocr_preview(frame)
    
    def _update_ocr_preview(self, frame):
        """Update live OCR preview"""
        try:
            x, y, w, h = self.roi
            roi_img = frame[y:y + h, x:x + w]
            
            # Preprocess
            gray = cv2.cvtColor(roi_img, cv2.COLOR_BGR2GRAY)
            gray = cv2.resize(gray, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
            gray = cv2.GaussianBlur(gray, (3, 3), 0)
            _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            
            config = '--psm 7 -c tessedit_char_whitelist=0123456789+.STA'
            text = pytesseract.image_to_string(thresh, config=config).strip()
            self.ocr_display.setText(text if text else "No text detected")
        except Exception as e:
            self.ocr_display.setText(f"Error: {str(e)}")
    
    def _update_preview(self):
        """Timer callback untuk auto-play"""
        if self.is_playing and self.current_frame_idx < self.total_frames - 1:
            self._show_frame(self.current_frame_idx + 1)
            self.frame_slider.blockSignals(True)
            self.frame_slider.setValue(self.current_frame_idx)
            self.frame_slider.blockSignals(False)
    
    def _toggle_play(self):
        """Toggle play/pause"""
        if not self.cap:
            QMessageBox.warning(self, "Warning", "Please select a video first")
            return
        
        self.is_playing = not self.is_playing
        self.play_btn.setText("⏸ Pause" if self.is_playing else "▶ Play")
        
        if self.is_playing:
            self.preview_timer.start(int(1000 / self.video_fps) if self.video_fps > 0 else 33)
        else:
            self.preview_timer.stop()
    
    def _on_slider_moved(self, value):
        """Slider moved"""
        self._show_frame(value)
    
    def _on_roi_changed(self):
        """ROI spinbox changed"""
        x = self.roi_spinboxes['x'].value()
        y = self.roi_spinboxes['y'].value()
        w = self.roi_spinboxes['width'].value()
        h = self.roi_spinboxes['height'].value()
        
        if x > 0 and y > 0 and w > 0 and h > 0:
            self.roi = (x, y, w, h)
            if self.current_frame is not None:
                self._show_frame(self.current_frame_idx)
    
    def _select_output(self):
        """Select output folder"""
        folder = QFileDialog.getExistingDirectory(self, "Select Output Folder")
        if folder:
            self.output_input.setText(folder)
    
    def _start_processing(self):
        """Start video processing"""
        # Validation
        if not self.video_path:
            QMessageBox.warning(self, "Warning", "⚠️ Please select a video")
            return
        if not self.roi or not all(self.roi):
            QMessageBox.warning(self, "Warning", "⚠️ Please define ROI (X, Y, Width, Height)")
            return
        
        output_folder = self.output_input.text()
        try:
            Path(output_folder).mkdir(parents=True, exist_ok=True)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"❌ Cannot create output folder: {str(e)}")
            return
        
        # Start worker
        self.worker = ProcessWorker(
            self.video_path,
            self.roi,
            self.interval_spin.value(),
            output_folder,
            self.skip_spin.value()
        )
        self.worker.signals.progress.connect(self._on_progress)
        self.worker.signals.log.connect(self._on_log)
        self.worker.signals.stats.connect(self._on_stats)
        self.worker.signals.finished.connect(self._on_finished)
        
        self.process_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.log_display.clear()
        self.log_display.append("🔄 Processing dimulai...\n")
        self.progress_bar.setValue(0)
        
        self.worker.start()
        self.statusBar().showMessage("Processing in progress...")
    
    def _stop_processing(self):
        """Stop processing"""
        if self.worker:
            self.worker.stop()
            self.log_display.append("⏹️  Stopping processing...")
            self.stop_btn.setEnabled(False)
    
    def _on_progress(self, value):
        """Update progress bar"""
        self.progress_bar.setValue(value)
    
    def _on_log(self, message):
        """Add log message"""
        self.log_display.append(message)
        # Auto-scroll to bottom
        self.log_display.verticalScrollBar().setValue(
            self.log_display.verticalScrollBar().maximum()
        )
    
    def _on_stats(self, stats):
        """Display statistics"""
        msg = f"""
        <b>Screenshots Saved:</b> {stats['saved']}<br>
        <b>OCR Attempts:</b> {stats['attempts']}<br>
        <b>OCR Success:</b> {stats['success']}<br>
        <b>OCR Accuracy:</b> {stats['accuracy']:.1f}%
        """
        self.stats_display.setText(msg)
    
    def _on_finished(self):
        """Processing finished"""
        self.process_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.log_display.append("\n✅ Processing selesai!")
        self.statusBar().showMessage("✓ Processing completed")
    
    def closeEvent(self, event):
        """Cleanup on close"""
        if self.preview_timer.isActive():
            self.preview_timer.stop()
        if self.cap:
            self.cap.release()
        event.accept()


def main():
    app = QApplication(sys.argv)
    window = STACaptureGUI()
    window.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
